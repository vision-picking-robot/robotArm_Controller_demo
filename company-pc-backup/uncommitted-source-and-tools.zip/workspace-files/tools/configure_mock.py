"""Generate clearly synthetic calibration and feedback; never marks hardware verified."""
from datetime import datetime, timezone
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'robotArm_Controller_demo'))
from vision_picking.contracts import PickRequest

camera = dict(session_id='mock-session', camera_generation=1, camera_id='mock-camera', width=640, height=480)
calibration = dict(camera=camera, region='legacy', revision='mock-only-v1', corners=[
    dict(pixel=pixel, pose=xyz + [0., 180., 0.]) for pixel, xyz in [
        ([0., 0.], [400., -100., 0.]), ([639., 0.], [600., -100., 0.]),
        ([639., 479.], [600., 100., 0.]), ([0., 479.], [400., 100., 0.])]])
config = dict(mock_mode=True, namespace='dsr01', robot_ip='110.120.1.63', robot_port=12345,
              calibration_verified=False, tcp_verified=False, waypoints_verified=False,
              gripper_verified=False, workspace_verified=False, calibration=calibration,
              min_confidence=0.6, workspace_mm=dict(min=[-650., -650., 10.], max=[650., 650., 600.]),
              class_map=dict(snack_box='snack_box', snack_pepero='snack_pepero', beverage_pet='beverage_pet',
                             pet_bottle='pet_bottle', can='can', canned_meat='canned_meat', wet_tissue='wet_tissue', wet_wipes='wet_wipes'),
              grasp_feedback={name: dict(calibrated=False, min_position_pulses=100, max_position_pulses=600, min_current=100)
                              for name in ['snack_box', 'snack_pepero', 'beverage_pet', 'pet_bottle', 'can', 'canned_meat', 'wet_tissue', 'wet_wipes']})
dest = ROOT / 'robotArm_Controller_demo'
(dest / 'config/integration.json').write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
example = dict(schema_version='1.0', simulation_only=True, request_id='mock-pick-001', camera=camera, frame_id=1,
               captured_at=datetime.now(timezone.utc).isoformat(), model_version='mock-model-v1', object_index=0,
               detection=dict(class_id=0, label='snack_box', confidence=.95, xyxy=[280., 200., 360., 280.], center_px=[320., 240.]),
               calibration_revision='mock-only-v1', box_slot=1)
(dest / 'config/payload.example.json').write_text(json.dumps(example, indent=2), encoding='utf-8')
(dest / 'config/payload.schema.json').write_text(json.dumps(PickRequest.model_json_schema(), indent=2), encoding='utf-8')
print('Generated mock calibration, JSON Schema and timestamped example')

from pathlib import Path
import json
import yaml

ROOT = Path(__file__).resolve().parents[1]
source = ROOT/'robotArm_Controller'
assets = dict(
    communication=dict(legacy_robot_ip=None, legacy_robot_port=12345,
                       web_robot_ip='110.120.1.63', web_robot_port=12345, namespace='dsr01', rosbridge_port=9090,
                       transport='Doosan driver shared DRFL connection; ROS 2 services; no invented raw TCP robot packets',
                       gripper=dict(model='RH-P12-RN-A', protocol='Modbus RTU over tool flange RS-485', port=1,
                                    baud=57600, bytesize=8, parity='none', stopbits=1, slave_id=1,
                                    open_pulses=0, close_pulses=740, legacy_test_goal_current_mA=400,
                                    open_settle_ms=500, response_timeout_ms=1000,
                                    goal_register=282, torque_register=256, current_register=275,
                                    feedback_register=285, feedback_count=7,
                                    status_services=['/dsr01/warehouse_gripper/status','/dsr01/warehouse_gripper/open','/dsr01/warehouse_gripper/close'])),
    poses=yaml.safe_load((source/'warehouse_motion/config/poses.yaml').read_text(encoding='utf-8')),
    products=yaml.safe_load((source/'warehouse_motion/config/products.yaml').read_text(encoding='utf-8')),
    transforms=dict(camera_to_base_matrix=None, camera_to_base_calibration_status='No measured calibration in audited repositories',
                    tool_to_base_rotation='Rz(A) Ry(B) Rz(C); angles degrees; translation mm',
                    tool_relative_translation='delta_base = R_base_tool @ delta_tool',
                    planar_web='Barycentric projective mapping from four taught pixel/BASE correspondences; no saved correspondences found',
                    rgbd_reference='P_camera_m = depth_m * inverse(K) * [u,v,1]; P_base_m = T_base_camera * [P_camera_m,1]; m→mm ×1000; RPY radians is not Doosan ZYZ degrees'),
    provenance='See source-audit.json (original), source-audit.final.json (delivered), robotArm_Controller_demo/provenance.json',
    certainty=dict(physical_robot_connection_tested=False, physical_failure_root_cause_confirmed=False,
                   source_confirmed_completion_bug='Moving/Moving Status register 285 packed word; corrected code selected',
                   physical_hypotheses=['plugin not spawned/active','serial ownership conflict','SDK/firmware/port mismatch','power/wiring']))
(ROOT/'deliverables/legacy-assets.json').write_text(json.dumps(assets, ensure_ascii=False, indent=2),encoding='utf-8')

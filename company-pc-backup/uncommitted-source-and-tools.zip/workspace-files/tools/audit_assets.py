"""Read-only repository inventory with exact source evidence and hashes."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REPOS = ['ryankim8815_yolov8', 'robotArm_Controller_demo', 'robotArm_Controller', 'e0509_gripper_description']
REPOS += ['references/robot_depth_camera', 'references/rfid-pick-and-place']


def git(repo, *args):
    result = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True)
    return result.stdout.strip() if result.returncode == 0 else None


def main():
    out = ROOT / 'deliverables'
    out.mkdir(exist_ok=True)
    audit = {'repositories': {}, 'manifests': [], 'control_evidence': []}
    for name in REPOS:
        repo = ROOT / name
        audit['repositories'][name] = {'origin': git(repo, 'remote', 'get-url', 'origin'), 'commit': git(repo, 'rev-parse', 'HEAD')}
        for path in sorted(repo.rglob('*')):
            if not path.is_file() or '.git' in path.parts:
                continue
            is_manifest = (path.name in {'package.xml', 'CMakeLists.txt', 'setup.py', 'pyproject.toml'}
                           or 'requirements' in path.name or 'Dockerfile' in path.name)
            if is_manifest:
                source = path.read_text(encoding='utf-8-sig')
                entry = {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'lines': [{'line': i, 'text': line} for i, line in enumerate(source.splitlines(), 1)]}
                if path.name == 'package.xml':
                    xml = ET.fromstring(source)
                    entry.update(buildtool_depend=[e.text for e in xml.findall('buildtool_depend')],
                                 build_type=[e.text for e in xml.findall('export/build_type')])
                audit['manifests'].append(entry)
            if name == 'robotArm_Controller' and path.suffix in {'.py', '.yaml', '.cpp', '.hpp', '.srv', '.md'}:
                for i, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
                    if any(term in line.lower() for term in ('posx', 'posj', 'max_vel', 'max_acc', 'radius', 'host:=', 'port:=', 'zyz', 'homograph', 'matrix', 'moving_status', '57600', 'register', 'create_client', 'create_service', 'create_subscription', 'create_publisher')):
                        audit['control_evidence'].append({'path': path.relative_to(ROOT).as_posix(), 'line': i, 'text': line})
    filename = 'source-audit.final.json' if '--final' in sys.argv else 'source-audit.json'
    (out / filename).write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    hashes = {}
    for path in (ROOT / REPOS[0] / 'app/static').rglob('*'):
        if path.suffix in {'.html', '.css'}:
            hashes[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    baseline = out / 'ui-baseline.json'
    if not baseline.exists():
        baseline.write_text(json.dumps(hashes, indent=2), encoding='utf-8')
    print(f"Audited {len(audit['manifests'])} manifests; {len(audit['control_evidence'])} control evidence lines")
    try:
        request = urllib.request.Request('https://api.github.com/orgs/vision-picking-robot/repos?per_page=100', headers={'User-Agent': 'vision-picking-audit'})
        repos = json.load(urllib.request.urlopen(request, timeout=20))
        (out / 'organization-repositories.json').write_text(json.dumps([{'name': r['name'], 'url': r['html_url'], 'size': r['size'], 'default_branch': r['default_branch']} for r in repos], indent=2), encoding='utf-8')
    except Exception as exc:
        print(f'Organization inventory unavailable: {exc}')


if __name__ == '__main__':
    main()

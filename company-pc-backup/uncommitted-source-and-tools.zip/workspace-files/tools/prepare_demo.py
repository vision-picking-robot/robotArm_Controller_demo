"""Copy audited pure control logic and the corrected gripper plugin without running legacy nodes."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / 'robotArm_Controller_demo'
PACKAGE = DEMO / 'vision_picking'
PACKAGE.mkdir(parents=True, exist_ok=True)
(PACKAGE / 'legacy').mkdir(exist_ok=True)
(PACKAGE / 'legacy/__init__.py').write_text('', encoding='utf-8')
provenance = []
copies = []
for name in ['safe_move.py', 'validation.py', 'config_loader.py', 'ros_motion_backend.py', 'ros_calls.py', 'gripper_feedback.py']:
    copies.append((ROOT / 'robotArm_Controller/warehouse_motion/warehouse_motion' / name, PACKAGE / 'legacy' / name))
copies.append((ROOT / 'ryankim8815_yolov8/app/pick_plane.py', PACKAGE / 'pick_plane.py'))
for source, target in copies:
    text = source.read_text(encoding='utf-8-sig')
    text = text.replace('from warehouse_motion.', 'from vision_picking.legacy.')
    target.write_text(text, encoding='utf-8')
    provenance.append(dict(source=source.relative_to(ROOT).as_posix(), destination=target.relative_to(DEMO).as_posix(), sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
for folder in ['config', 'ros']:
    (DEMO / folder).mkdir(exist_ok=True)
for name in ['poses.yaml', 'products.yaml']:
    source = ROOT / 'robotArm_Controller/warehouse_motion/config' / name
    target = DEMO / 'config' / name
    shutil.copy2(source, target)
    provenance.append(dict(source=source.relative_to(ROOT).as_posix(), destination=target.relative_to(DEMO).as_posix(), sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
source = ROOT / 'robotArm_Controller/warehouse_gripper'
shutil.copytree(source, DEMO / 'ros/warehouse_gripper', dirs_exist_ok=True)
for path in source.rglob('*'):
    if path.is_file():
        provenance.append(dict(source=path.relative_to(ROOT).as_posix(), destination='ros/warehouse_gripper/' + path.relative_to(source).as_posix(), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(DEMO / 'provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Extracted {len(provenance)} source assets')
